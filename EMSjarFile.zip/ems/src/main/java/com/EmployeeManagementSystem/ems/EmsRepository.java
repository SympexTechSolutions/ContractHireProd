package com.EmployeeManagementSystem.ems;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EmsRepository extends JpaRepository<Employee,Integer> {

}
